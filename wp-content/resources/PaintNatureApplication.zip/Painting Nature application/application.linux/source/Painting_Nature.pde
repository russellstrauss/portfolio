//work on rain
//make an erase button




import java.util.Random;
import javax.swing.*;

  //Variables for the grass:
  float sign;
  color darkGreen = #005522;
  color green = #009911;
  color lightGreen = #33bb00;
  
  color summerGrass1 = #9ABB1E;
  color summerGrass2 = #E3EB7C;
  color summerGrass3 = lightGreen;//#FFFBAD;
  
  color autumnGrass1 = #7F0B00;
  color autumnGrass2 = #8C3700;
  color autumnGrass3 = #4C1202;
  
  color winterGrass1 = #072B28;
  color winterGrass2 = #0D6860;
  color winterGrass3 = #17ADA1;
  
  color grassColor;
  int colorChooser;
  int grassButtonPressed = 0;
  
  
  
  //Variables for the leaves:
  color maroon = #4C1413;
  color brown = #A22217;
  color orange = #D86B16;
  color leafRed = #F4AA23;
  color gold = #F9CB3A;
  
  color winterLeaves1 = #FFFFFF;
  color winterLeaves2 = #FFFFFF;
  color winterLeaves3 = #FFFFFF;
  color winterLeaves4 = #FFFFFF;
  color winterLeaves5 = #FFFFFF;
  
  color springLeaves1 = #ffd2f7;
  color springLeaves2 = #ffb7f2;
  color springLeaves3 = #ff96ec;
  color springLeaves4 = #ff83e9;
  color springLeaves5 = #fe73e5;

  color summerLeaves1 = green;
  color summerLeaves2 = darkGreen;
  color summerLeaves3 = lightGreen;
  color summerLeaves4 = green;
  color summerLeaves5 = darkGreen;

  
  int leavesButtonPressed = 0;
  float leafSize;
  color leafColor;
  
  //Variables for the water:
  color lightBlue = #69D2E7;
  color blue = #415D9B;
  color darkBlue = #170C91;
  float diameter;
  
  color winterWater1 = #FFFFFF;
  color winterWater2 = #FFFFFF;
  color winterWater3 = #FFFFFF;  
  
  color springWater1 = #69D2E7;
  color springWater2 = #415D9B;
  color springWater3 = #170C91;

  color summerWater1 = #69D2E7;
  color summerWater2 = #415D9B;
  color summerWater3 = #170C91;

  color autumnWater1 = #69D2E7;
  color autumnWater2 = #415D9B;
  color autumnWater3 = #170C91;
  
  int waterButtonPressed = 0;
  int rainButtonPressed = 0;
  int dirtButtonPressed = 0;
  int waterColor;
  
  
  //Variables for trees:
  int treesButtonPressed = 0;
  int treesColor;
  
  
  
  //Sunshine:
  color sunshine1 = #ffd202;
  color sunshine2 = #ffe775;
  color sunshine3 = #ffee9c;
  color sunshineColor;
  int sunshineButtonPressed = 0;
  
  //Clouds:
  int cloudsButtonPressed = 0;
  
  //nighttime:
  int nightButtonPressed = 0;
  
  //Sky:
  color springSky1 = #3A88B5;
  color springSky2 = #1DA8F2;
  color springSky3 = #1DA8F2;
  
  color autumnSky1 = #E79B19;
  color autumnSky2 = #804e51;
  color autumnSky3 = #B6122D;  
  
  color summerSky1 = #3A88B5;
  color summerSky2 = #1DA8F2;
  color summerSky3 = #1DA8F2;

  color winterSky1 = #C4DCE9;
  color winterSky2 = #F2F8FC;
  color winterSky3 = #C4DCE9;
  
  //clouds:
  color springClouds1 = #FEE1FF;
  color springClouds2 = #FFA1E8;
  
  color winterClouds1 = #EEECFF;
  color winterClouds2 = #76757F;
  
  color summerClouds1 = #FFFFFF;
  color summerClouds2 = #D8C306;
  
  color autumnClouds1 = #FFCDAA;
  color autumnClouds2 = #FFA359;
  
  //trees:
  color winterTrees1 = #27333A;
  
  color summerTrees1 = #A8C71F;
  color summerTrees2 = #A2EA21;
  color summerTrees3 = #C9ED19;
  
  color springTrees1 = #3B9113;
  color springTrees2 = #5EE610;
  color springTrees3 = #FAB4B4;
  
  color autumnTrees1 = #4C1413;
  color autumnTrees2 = #D86B16;
  color autumnTrees3 = #F4AA23;
  
  
  int skyButtonPressed = 0;
  int moonButtonPressed = 0;
  int starsButtonPressed = 0;
  int flowersButtonPressed = 0;
  
  
  //Other variables:
  color black = 0;
  color white = 255;
  int frame = 0;
  int inMenu = 0;
  int eraserSize = 25;
  int minusButtonPressed = 0;
  int plusButtonPressed = 0;
  int frameRateValue = 60;
  PImage[] frameHistory = new PImage[200];
  int actionNumber = 0;
  int undoButtonPressed = 0;
  int redoButtonPressed = 0;
  int clearButtonPressed = 0;
  int eraseButtonPressed = 0;
  int pageDownButtonPressed = 0;
  int pageUpButtonPressed = 0;
  int saveButtonPressed = 0;
  int numberOfUndos = 0;
  int numberOfRedos = 0;
  int n = 0;
  int saveDisplay = 0;
  int page = 1;
  int waterXOld = 0;
  int waterYOld = 0;
  float hypotenuse = 0;
  int hypoIncrement;
  
  int dirtBrown = #451F08;
  
  //Variables for the seasons:
  int season = 0;
  int winter = 1;
  int spring = 2;
  int summer = 3;
  int autumn = 4;
  
      int grassColor1;
      int grassColor2;
      int grassColor3; 
      
      int leafColor1;
      int leafColor2;
      int leafColor3;
      int leafColor4;
      int leafColor5;
      
      int waterColor1;
      int waterColor2;
      int waterColor3;
      
      int skyColor1;
      int skyColor2;
      int skyColor3;
      
      int cloudColor1;
      int cloudColor2;
      
      int treesColor1;
      int treesColor2;
      int treesColor3;
      
      
  int winterButtonPressed = 0;
  int springButtonPressed = 0;
  int summerButtonPressed = 0;
  int autumnButtonPressed = 0;
      
  
  Random randomGenerator = new Random();
  
  //State switching:
  int state = 0;
  final int grass = 1;
  final int leaves = 2;
  final int dirt = 3;
  final int rain = 4;
  final int erase = 5;
  final int sunshine = 6;
  final int clouds = 7;
  final int sky = 8;
  final int nighttime = 9;
  final int moon = 10; 
  final int stars = 11;
  final int trees = 12;
  final int flowers = 13;
  final int numberOfStates = 13;
  
  int mouseHeld = 0;
  int rightPressed = 0;

  void setup(){
    
    size(600, 800);   
    fill(0);
    stroke(255);
    smooth();
    background(black);
    PFont font = loadFont("Harrington.vlw");
    textFont(font, 16);
    textAlign(CENTER);
    cursor(CROSS);
  }

  void draw() {
     frameRate(frameRateValue);
     if (frameRateValue>600) { frameRateValue -= 20; }
     
     //Erasing the screen:
     if (rightPressed == 1) {
       background(black);
       rightPressed = 0;
     }
     
     
    //Variables for the menu bar:
    PImage menuBG = loadImage("menu.jpg");
    PImage grassImage = loadImage("grass.png");
    PImage leavesImage = loadImage("leaves.png");
    PImage rainImage = loadImage("rain.png");
    PImage autumnImage = loadImage("autumn.png");
    PImage summerImage = loadImage("summer.png");
    PImage springImage = loadImage("spring.png");
    PImage winterImage = loadImage("winter.png");
    PImage autumnMenu = loadImage("autumnMenu.png");
    PImage summerMenu = loadImage("summerMenu.png");     
    PImage springMenu = loadImage("springMenu.png");
    PImage winterMenu = loadImage("winterMenu.png");
    PImage sunshineImage = loadImage("sunshine.png");
    PImage cloudsImage = loadImage("clouds.png");
    PImage skyImage = loadImage("sky.png");
    PImage nightImage = loadImage("night.png");
    PImage moonImage = loadImage("moon.png");
    PImage dirtImage = loadImage("dirt.png");
    PImage starsImage = loadImage("stars.png");
    PImage flowersImage = loadImage("flowers.png");
    
    //Page 2:
    PImage treesImage = loadImage("trees.png");

  switch(state) {
    
    
    case grass:
      
      if (season == winter) {
        grassColor1 = winterGrass1;
        grassColor2 = winterGrass2;
        grassColor3 = winterGrass3;
      }
      
      if (season == spring) {
         grassColor1 = lightGreen;
         grassColor2 = green;
         grassColor3 = darkGreen; 
      }
      
      if (season == summer) {
        grassColor1 = summerGrass1;
        grassColor2 = summerGrass2;
        grassColor3 = summerGrass3;
      }
      
      if (season == autumn) {
        grassColor1 = autumnGrass1;
        grassColor2 = autumnGrass2;
        grassColor3 = autumnGrass3;
      }
      
      
      //Making the grass three different shades of green using the randomizer:
      colorChooser = randomGenerator.nextInt(3)+1;
      
      sign = random(0,1);
      if (sign == 0){
        sign = -1;
      }
      if (colorChooser == 1){
        grassColor = grassColor1;
      }
      if (colorChooser == 2){
        grassColor = grassColor2;
      }
      if (colorChooser == 3){
        grassColor = grassColor3;
      }
      
      //Drawing the grass:
      
      stroke(grassColor);  
      if (mouseHeld == 1 && inMenu !=1) {
        line(mouseX+random(0,20)*sign, mouseY-random(0,20)*sign, mouseX+random(0,20), mouseY+random(0,20));
        line(mouseX+random(0,20)*sign, mouseY-random(0,20)*sign, mouseX+random(0,20), mouseY+random(0,20));
        line(mouseX+random(0,20)*sign, mouseY-random(0,20)*sign, mouseX+random(0,20), mouseY+random(0,20));
        line(mouseX+random(0,20)*sign, mouseY-random(0,20)*sign, mouseX+random(0,20), mouseY+random(0,20));
      }
      
      break;
      
      case sunshine:
        
        colorChooser = randomGenerator.nextInt(3)+1;
        
        
        if (colorChooser == 1){
          sunshineColor = sunshine1;
        }
        if (colorChooser == 2){
          sunshineColor = sunshine2;
        }
        if (colorChooser == 3){
          sunshineColor = sunshine3;
        }
        
        //Drawing the sunshine:
        
        stroke(sunshineColor);
      
        if (mouseHeld == 1 && season != 0 && inMenu != 1){
           fill(sunshineColor);
           line(0, 0, mouseX, mouseY); 
        }
      break;
      
      case leaves:
      
          colorChooser = randomGenerator.nextInt(5)+1;
          
          if (season == autumn) {
            leafColor1 = gold;
            leafColor2 = maroon;
            leafColor3 = brown;
            leafColor4 = leafRed;
            leafColor5 = orange; 
          }
        
          if (season == spring) { 
            leafColor1 = springLeaves1;
            leafColor2 = springLeaves2;
            leafColor3 = springLeaves3;
            leafColor4 = springLeaves4;
            leafColor5 = springLeaves5; 
          }   
        
          if (season == summer) {
            leafColor1 = summerLeaves1;
            leafColor2 = summerLeaves2;
            leafColor3 = summerLeaves3;
            leafColor4 = summerLeaves4;
            leafColor5 = summerLeaves5; 
          }
               
          if (season == winter) {
            leafColor1 = winterLeaves1;
            leafColor2 = winterLeaves2;
            leafColor3 = winterLeaves3;
            leafColor4 = winterLeaves4;
            leafColor5 = winterLeaves5; 
          }
        
          //Choosing a random sign, + or -
          sign = random(0,1);
          if (sign == 0){
            sign = -1;
          }
          
          
          if (colorChooser == 1){
            leafColor = leafColor1;
          }
          if (colorChooser == 2){
            leafColor = leafColor2;
          }
          if (colorChooser == 3){
            leafColor = leafColor3;
          }
          if (colorChooser == 4){
            leafColor = leafColor4;
          }
          if (colorChooser == 5){
            leafColor = leafColor5;
          }
          
          //Drawing the leaves:
          leafSize = random(4, 10);
          
          fill(leafColor);
          stroke(leafColor);
          if (season == winter) {
            stroke(#CCCCCC); 
          }
          
          if (mouseHeld == 1 && inMenu != 1 && frame%2==0) {
            quad(mouseX-random(0,10), mouseY-random(0,10)*sign, mouseX-random(0,10), mouseY-random(0, 10),mouseX+random(0,10), mouseY-random(0,10)*sign, mouseX+random(0,10)*sign, mouseY+random(0,10));  

          if (mouseHeld == 1 && inMenu != 1 && frame%8==0) {
            triangle(mouseX, mouseY+leafSize, mouseX-leafSize, mouseY-leafSize, mouseX+leafSize, mouseY-leafSize);
          }  
          if (mouseHeld == 1 && inMenu != 1 && frame%8==4) {
            triangle(mouseX, mouseY-leafSize+random(0,4), mouseX-leafSize+random(0,4), mouseY+leafSize+random(0,4), mouseX+leafSize+random(0,4), mouseY+leafSize+random(0,4));
          }  
            if (waterButtonPressed == 1){
            rotate(PI/3.0);
            }
            //triangle(mouseX, mouseY-leafSize, mouseX-leafSize, mouseY+leafSize, mouseX+leafSize, mouseY+leafSize);
          }
      break;
      
      case dirt:
        
        if (mouseHeld == 1 && season != 0 && inMenu != 1) {
           for (int i = 0; i<random(0,10000); i++) {
              stroke(#1A0A05);
              point(mouseX-random(0,30)+random(0,30), mouseY+random(0,30)-random(0,30));
              stroke(dirtBrown);
              point(mouseX-random(0,30)+random(0,30), mouseY+random(0,30)-random(0,30));
              stroke(#2C1616);
              point(mouseX-random(0,20)+random(0,20), mouseY+random(0,20)-random(0,20));
          } 
          for (int i = 0; i<20; i++) {
             stroke(#2E1811);
             line(mouseX-random(0, 20)+random(0, 20), mouseY+random(0,20)-random(0, 20), mouseX-random(0, 20)+random(0, 20),mouseY-random(0, 20)+random(0, 20)); 
             stroke(#1A0A05);
             line(mouseX-random(0, 20)+random(0, 20), mouseY+random(0,20)-random(0, 20), mouseX-random(0, 20)+random(0, 20),mouseY-random(0, 20)+random(0, 20)); 
          } 
        }
        
      break;
      
      case rain:
      
          colorChooser = randomGenerator.nextInt(3)+1;
        
          if (season == spring) { 
            waterColor1 = springWater1;
            waterColor2 = springWater2;
            waterColor3 = springWater3;
          }   
        
          if (season == summer) {
            waterColor1 = summerWater1;
            waterColor2 = summerWater2;
            waterColor3 = summerWater3;
          }

          if (season == autumn) {
            waterColor1 = autumnWater1;
            waterColor2 = autumnWater2;
            waterColor3 = autumnWater3;
          }
               
          if (season == winter) {
            waterColor1 = winterWater1;
            waterColor2 = winterWater2;
            waterColor3 = winterWater3; 
          }        
        
        
          //Choosing a random sign, + or -
          sign = random(0,1);
          if (sign == 0){
            sign = -1;
          }

          if (colorChooser == 1){
            waterColor = waterColor1;//(darkBlue)
          }
          if (colorChooser == 2 || colorChooser == 3){
            waterColor = waterColor2;//(blue)
          }
        
        //drawing the rain:  
        fill(waterColor);
        stroke(waterColor);
        if (mouseHeld == 1 && inMenu != 1 && (frame%2)==0 && season != winter) {
          line(mouseX-(random(0,5)*sign), mouseY-10, mouseX+(random(0,5)*sign), mouseY+5);
        }
        if (season == winter && inMenu != 1 && mouseHeld == 1 && (frame%2)==0) {
          line(mouseX-(random(0,5)*sign), mouseY-10, mouseX, mouseY-5);
          line((mouseX-5)+random(0,3)*sign, mouseY-7, (mouseX)+random(0,3)*sign, mouseY-7);
          line(mouseX+(random(0,5)*sign), mouseY-10, mouseX-3, mouseY-5);
        }

      break;
      
      case erase:
        if (mouseHeld == 1) {
         fill(black);
         stroke(black);
         ellipse(mouseX, mouseY, eraserSize, eraserSize);
        }
      break;
      
      case clouds:
      
        if (season == winter) {
          cloudColor1 = winterClouds1;
          cloudColor2 = winterClouds2;
        }
        if (season == spring) {
          cloudColor1 = springClouds1;
          cloudColor2 = springClouds2;
        } 
        if (season == summer) {
          cloudColor1 = summerClouds1;
          cloudColor2 = summerClouds2;
        }
        if (season == autumn) {
          cloudColor1 = autumnClouds1;
          cloudColor2 = autumnClouds2;
        }        
        
      
        if (mouseHeld == 1 && inMenu != 1 && season != 0){
            stroke(cloudColor1);
          for (int i = 0; i<random(0,500); i++) {
              line(mouseX-random(0,20)+random(0,20), mouseY+random(0,20)-random(0,20), mouseX-random(0,20)+random(0,20), mouseY+random(0,20)-random(0,20));
              point(mouseX-random(0,20)+random(0,20), mouseY+random(0,20)-random(0,20));
          }
          stroke(cloudColor2, 50);
          for (int i = 0; i<random(0,500); i++) {
              line(mouseX-random(0,20)+random(0,20), mouseY+random(0,20)-random(0,20), mouseX-random(0,20)+random(0,20), mouseY+random(0,20)-random(0,20));
              point(mouseX-random(0,20)+random(0,20), mouseY+random(0,20)-random(0,20));
          }
        }       
      
      break;
      
      case sky:
        
        if (season == winter) {
           skyColor1 = winterSky1;
           skyColor2 =  winterSky2;
           skyColor3 = winterSky3;
        }

        if (season == spring) {
           skyColor1 = springSky1;
           skyColor2 =  springSky2;
           skyColor3 = springSky3;
        }      

        if (season == summer) {
           skyColor1 = summerSky1;
           skyColor2 =  summerSky2;
           skyColor3 = summerSky3;
        }      
      
        if (season == autumn) {
           skyColor1 = autumnSky1;
           skyColor2 =  autumnSky2;
           skyColor3 = autumnSky3;
        } 
      
        if (mouseHeld == 1 && inMenu != 1 && season != 0){
          
          for (int i = 0; i<random(0, 1000); i++) {
              stroke(skyColor1,128);
              line(mouseX-random(0,100)+random(0,100), mouseY-random(0,100)+random(0,100), mouseX-random(0,100)+random(0,100), mouseY-random(0,100));        
              stroke(skyColor2,75);
              line(mouseX-random(0,70)+random(0,70), mouseY+random(0,70)-random(0,70), mouseX-random(0,70)+random(0,70), mouseY+random(0,40)-random(0,60));        
          }
          //dots:
          if (season != autumn) {
            for (int i = 0; i<random(0,10000); i++) {
                stroke(skyColor3);
                point(mouseX-random(0,50)+random(0,50), mouseY+random(0,50)-random(0,50));
            }
          } 
        }
        
      break;
      
      case nighttime:
      
        if (mouseHeld == 1 && season != 0 && inMenu != 1){
          
          for (int i = 0; i<random(0, 1000); i++) {
              stroke(black,128);
              line(mouseX-random(0,100)+random(0,100), mouseY+random(0,100)-random(0,100), mouseX-random(0,100)+random(0,100), mouseY+random(0,100)-random(0,100));        
              stroke(#006699,75);
              line(mouseX-random(0,50)+random(0,50), mouseY+random(0,50)-random(0,50), mouseX-random(0,50)+random(0,50), mouseY+random(0,30)-random(0,40));        
          }
    
          for (int i = 0; i<random(0,10000); i++) {
              stroke(skyColor2);
              point(mouseX-random(0,30)+random(0,30), mouseY+random(0,30)-random(0,30));
          }
          
       } 
      
      break;
      
      case moon:
        
        if (mouseHeld == 1 && season != 0 && inMenu != 1){
          
          for (int i = 0; i<random(0, 1000); i++) {
              stroke(black,128);
              line(mouseX-random(0,100)+random(0,100), mouseY+random(0,100)-random(0,100), mouseX-random(0,100)+random(0,100), mouseY+random(0,100)-random(0,100));        
              stroke(#006699,75);
              line(mouseX-random(0,50)+random(0,50), mouseY+random(0,50)-random(0,50), mouseX-random(0,50)+random(0,50), mouseY+random(0,30)-random(0,40));        
          }
    
          for (int i = 0; i<random(0,10000); i++) {
              stroke(skyColor2);
              point(mouseX-random(0,30)+random(0,30), mouseY+random(0,30)-random(0,30));
          }          
       } 
        if (mouseHeld == 1 && inMenu != 1 && season != 0){
            stroke(white);
          for (int i = 0; i<random(0,1000); i++) {
              line(mouseX-random(0,20)+random(0,20), mouseY+random(0,20)-random(0,20), mouseX-random(0,20)+random(0,20), mouseY+random(0,20)-random(0,20));
              point(mouseX-random(0,20)+random(0,20), mouseY+random(0,20)-random(0,20));
          }
        } 
       
      break;
      
      case stars:
      
          if (mouseHeld == 1 && inMenu != 1 && season != 0){
              for (int i = 0; i<random(0, 1000); i++) {
                  stroke(black,128);
                  line(mouseX-random(0,40)+random(0,40), mouseY+random(0,40)-random(0,40), mouseX-random(0,40)+random(0,40), mouseY+random(0,40)-random(0,40));        
                  stroke(#006699,75);
                  line(mouseX-random(0,25)+random(0,25), mouseY+random(0,25)-random(0,25), mouseX-random(0,25)+random(0,25), mouseY+random(0,30)-random(0,40));        
              }
        
              for (int i = 0; i<random(0,10000); i++) {
                  stroke(skyColor2);
                  point(mouseX-random(0,30)+random(0,30), mouseY+random(0,30)-random(0,30));
              }          
            
                stroke(white);
              for (int i = 0; i<random(0,100); i++) {
                  line(mouseX-random(0,10)+random(0,10), mouseY+random(0,10)-random(0,10), mouseX-random(0,10)+random(0,10), mouseY+random(0,10)-random(0,10));
                  point(mouseX-random(0,10)+random(0,10), mouseY+random(0,10)-random(0,10));
              }
          }      
      break;
      
      case trees:
                  if (mouseHeld == 1 && inMenu != 1 && season != 0){
                              if (season == winter) {
                                      treesColor1 = winterTrees1;
                              }
                    
                              if (season == spring) {
                                      treesColor1 = springTrees1;
                                      treesColor2 = springTrees2;
                                      treesColor3 = springTrees3;
                              }

                              if (season == summer) {
                                      treesColor1 = summerTrees1;
                                      treesColor2 = summerTrees2;
                                      treesColor3 = summerTrees3;
                              }
              
                              if (season == autumn) {
                                      treesColor1 = autumnTrees1;
                                      treesColor2 = autumnTrees2;
                                      treesColor3 = autumnTrees3;
                              }              
                              
                              int ran = 1000;
                              if (season == winter) {
                                ran = 10;
                              }
                              for (int i = 0; i<random(0, ran); i++) {
                                  
                                  if (season == winter){
                                    strokeWeight(3);
                                  }
                                  
                                  if (season == winter) {
                                              stroke(treesColor1,128);
                                              line(mouseX-random(0,10)+random(0,10), mouseY+random(0,10)-random(0,10), mouseX-random(0,100)+random(0,100), mouseY-random(0,100));        
                                             
                                  }
                                  
                                  
                                  
                                  
                                  if (season != winter) {
                                              stroke(treesColor1,128);
                                              line(mouseX-random(0,100)+random(0,100), mouseY+random(0,100)-random(0,100), mouseX-random(0,100)+random(0,100), mouseY+random(0,100)-random(0,100));        
                                              
            
                                              stroke(treesColor2, 75);
                                              line(mouseX-random(0,100)+random(0,100), mouseY+random(0,100)-random(0,100), mouseX-random(0,100)+random(0,100), mouseY+random(0,100)-random(0,100));        
      
                                   
                                              stroke(treesColor3,75);
                                              line(mouseX-random(0,50)+random(0,50), mouseY+random(0,50)-random(0,50), mouseX-random(0,50)+random(0,50), mouseY+random(0,30)-random(0,40));        

                                  }
                              }
                              
                              if (season != winter) {
                                    for (int i = 0; i<random(0,10000); i++) {
                                        stroke(treesColor3);
                                        point(mouseX-random(0,50)+random(0,50), mouseY+random(0,50)-random(0,50));
                                    }
                              }
                              strokeWeight(1);
                  
                } 

      break;
      
      case flowers:
      
      
                              if (mouseHeld == 1 && inMenu!= 1 && season != 0){
                    
                               if (hypoIncrement==0) {    
                                    colorChooser = (randomGenerator.nextInt(250)%6)+1;
                               }
                               
                              color flowerColor=0;
                              
                              if (colorChooser == 1){
                                flowerColor = #5822A6;
                              }
                              if (colorChooser == 2){
                                flowerColor = #FF753F;
                              }
                          
                              if (colorChooser == 3){
                                flowerColor = #DA0315;
                              }      
                    
                              if (colorChooser == 4){
                                flowerColor = #3E664B;
                              }
                        
                              if (colorChooser == 5){
                                flowerColor = #1A4E61;
                              }
                    
                              if (colorChooser == 6){
                                flowerColor = #CC016A;
                              }     
                              
                              println(colorChooser);
                              
                              stroke(#298A0A);
                              strokeWeight(3);
                              line(mouseX, mouseY, mouseX, mouseY+random(40, 50));
                    
                                    strokeWeight(1);
                          for (int i = 0; i<random(0,5000); i++) {
                              stroke(flowerColor);
                              line(mouseX-random(0,20)+random(0,20), mouseY+random(0,20)-random(0,20), mouseX-random(0,5)+random(0,5), mouseY+random(0,5)-random(0,5));
                              stroke(#E9AC16);
                              line(mouseX, mouseY, mouseX-random(0,10)+random(0,10), mouseY+random(0,10)-random(0,10));
                              
                          }
                    
                          hypoIncrement++;
                        } 
    
    
    break;
       
    }//end switch

     //Menu bar:
     fill(black);
     stroke(255);
     
     image(menuBG, 0,0, getWidth()-1, 39); 
     noFill();
     stroke(white);
     rect(0,0, getWidth()-1, 39);
     
     if (mouseY < 40) { inMenu = 1; }
     else { inMenu = 0;}  
     
     //Seasons menu bar:
     
     fill(black);    
     rect(0, 39, 80, 130);     
     
     if (season==autumn){
       image(autumnMenu, 1, 40, 79, 129);
     }
     
     if (season==summer){
       image(summerMenu, 1, 40, 79, 129);
     }
     
     if (season==winter){
       image(winterMenu, 1, 40, 79, 129);
     }
     
     if (season==spring){
       image(springMenu, 1, 40, 79, 129);
     }
     
     //winter:
     if (winterButtonPressed != 1) {
       image(winterImage, 10, 49, 60, 20);
     }
     noFill();
     stroke(black);
     if (season == winter) {
       stroke(white); 
     }     
     rect(10, 49, 60, 20);
     fill(black);
     text("Winter", 41, 64);
     
     //spring:
     if (springButtonPressed !=1) {
       image(springImage, 10, 79, 60, 20);
     }
     noFill();
     stroke(black);
     if (season == spring) {
       stroke(white); 
     }
     rect(10, 79, 60, 20);
     fill(black);
     text("Spring", 41, 94);
     
     //summer:
     if (summerButtonPressed != 1) {
       image(summerImage, 10, 109, 60, 20);
     }
     noFill();
     stroke(black);
     if (season == summer) {
       stroke(white); 
     }     
     rect(10, 109, 60, 20);
     fill(black);
     text("Summer", 41, 124);
     
     //autumn:
     if (autumnButtonPressed != 1) {
       image(autumnImage, 10, 139, 60, 20);
     }
     
     noFill();
     stroke(black);
     if (season == autumn) {
       stroke(white); 
     }     
     rect(10, 139, 60, 20);
     fill(white);
     text("Autumn", 41, 154);
      
      
     //Buttons:
     
     if (page == 1) {
         
         //Grass button:
                                   
                               stroke(black);
                               if (grassButtonPressed != 1) {
                                 image(grassImage, 10, 10, 40, 20);
                               } 
                               noFill();
                               
                               if (state == grass) {
                                 stroke(white); 
                               }     
                               rect(10,10, 40, 20);
                           
                               fill(white);
                               text("Grass", 31, 25);
                               
                               
                                 //Leaves button:
                                 
                               stroke(black);
                               if (leavesButtonPressed != 1) {
                                 image(leavesImage, 60, 10, 40, 20);
                               } 
                               noFill();
                               if (state == leaves) {
                                 stroke(white); 
                               }     
                               rect(60,10, 40, 20);
                           
                               fill(white);
                               text("Leaves", 81, 25);
                               
                               //Rain button:
                               
                               stroke(black);
                               if (rainButtonPressed != 1) {
                                 image(rainImage, 110, 10, 40, 20);
                               } 
                               noFill();
                               if (state == rain) {
                                 stroke(white); 
                               }     
                               rect(110,10, 40, 20);
                           
                               fill(white);
                               text("Rain", 131, 25);
                               
                                    //Water button:
                               
                               stroke(black);
                               if (dirtButtonPressed != 1) {
                                 image(dirtImage, 160, 10, 40, 20);
                               } 
                               noFill();
                               if (state == dirt) {
                                 stroke(white); 
                               }     
                               rect(160,10, 40, 20);
                           
                               fill(white);
                               text("Dirt", 181, 25);
                               
                                   //Sunshine button:
                               
                               stroke(black);
                               if (sunshineButtonPressed != 1) { 
                                 image(sunshineImage, 210, 10, 50, 20);
                               }
                               noFill();
                               if (state == sunshine) {
                                 stroke(white); 
                               }     
                               rect(210, 10, 50, 20);
                               
                               fill(black);
                               text("Sunshine", 236, 25);
                               
                                   //clouds button:
                               
                               if (cloudsButtonPressed != 1) {
                                 image(cloudsImage, 270, 10, 40, 20); 
                               }
                               stroke(black);
                               noFill();
                               if (state == clouds) {
                                 stroke(white); 
                               }     
                               rect(270, 10, 40, 20);
                               fill(black);
                               text("Clouds", 291, 26);
                               
                                   //sky button:
                               if (skyButtonPressed != 1) {
                                 image(skyImage, 320, 10, 40, 20);
                               }
                               
                               stroke(black);
                               noFill();
                               if (state == sky) {
                                 stroke(white); 
                               }     
                               rect(320, 10, 40, 20);
                               fill(white);
                               text("Sky", 341, 25);
                               
                                   //nighttime:
                               if (nightButtonPressed != 1) {
                                 image(nightImage, 370, 10, 40, 20);
                               }
                               
                               stroke(black);
                               noFill();
                               if (state == nighttime) {
                                 stroke(white); 
                               }     
                               rect(370, 10, 40, 20);
                               fill(white);
                               text("Night", 391, 25);     
                          
                                   //moon:
                               if (moonButtonPressed != 1) {
                                 image(moonImage, 420, 10, 40, 20);
                               }
                               
                               stroke(black);
                               noFill();
                               if (state == moon) {
                                 stroke(white); 
                               }     
                               rect(420, 10, 40, 20);
                               fill(white);
                               text("Moon", 441, 25);
                          
                          
                                   //stars:
                               if (starsButtonPressed != 1) {
                                 image(starsImage, 470, 10, 40, 20);
                               }
                               
                               stroke(black);
                               noFill();
                               if (state == stars) {
                                 stroke(white); 
                               }     
                               rect(470, 10, 40, 20);
                               fill(black);
                               text("Stars", 490, 23);
                               fill(white);
                               text("Stars", 492, 25);     
     } //end if (page==1)
     
     
     if (page == 2) {
       
                               stroke(black);
                               if (treesButtonPressed != 1) {
                                 image(treesImage, 10, 10, 40, 20);
                               } 
                               noFill();
                               
                               if (state == trees) {
                                 stroke(white); 
                               }     
                               rect(10,10, 40, 20);
                           
                               fill(white);
                               text("Trees", 31, 25); 
                               
                               //FLOWERS
                               
                               stroke(black);
                               if (flowersButtonPressed != 1) {
                                 image(flowersImage, 60, 10, 50, 20);
                               } 
                               noFill();
                               if (state == flowers) {
                                 stroke(white); 
                               }     
                               rect(60,10, 50, 20);
                           
                               fill(white);
                               text("Flowers", 86, 25);
       
       
       
     }
     
     
     // +/- button:    
     stroke(white);
     fill(black);
     rect(80, 39, 40, 20);
     fill(black);
     if (minusButtonPressed == 1) {
       fill(white); 
     }    
     rect(80, 59, 20, 20);
     fill(black);
     if (plusButtonPressed == 1) {
       fill(white); 
     }     
     rect(100, 59, 20, 20);
     fill(white);
     
     //minus:    
     line(86, 69, 94, 69);
     
     //plus:
     stroke(white);
     line(106, 69, 114, 69);
     line(110, 65, 110, 73);
     
     fill(white);
     text("Speed", 100, 54);
     
     //detecting it in the menu:
     if( (mouseX > 80 && mouseX < 100) && (mouseY > 59 && mouseY < 79) ){
       inMenu = 1;
     }
       
     if ( (mouseX > 100 && mouseX < 120) && (mouseY > 59 && mouseY < 79) ){
       inMenu=1;
     }
     
     if (mouseX < 80 && mouseY < 170) {
        inMenu = 1; 
     }
     
     if (mouseX > 404 && mouseY < 60) {
       inMenu=1; //clear/save/undo/redo buttons
     }
     
     fill(black);
     stroke(white);
     if (saveDisplay==1) fill(white);
     rect(getWidth()-40, 39, 39, 20);
     fill(white);
     text("Save", getWidth()-20, 55);
  
        
     fill(black);
     stroke(white);
     if (redoButtonPressed==1) fill(white);
     rect(getWidth()-79, 39, 39, 20);
     fill(white);
     text("Redo", getWidth()-59, 55);  

     fill(black);
     stroke(white);
     if (undoButtonPressed==1) fill(white);
     rect(482, 39, 39, 20);
     fill(white);
     text("Undo", getWidth()-98, 55);     
        
     fill(black);
     stroke(white);
     if (clearButtonPressed==1) fill(white);
     rect(443, 39, 39, 20);
     fill(white);
     text("Clear", 464, 55);

 
     fill(black);
     stroke(white);
     if (eraseButtonPressed == 1) fill(white);
     rect(404, 39, 39, 20);
     fill(white);
     text("Erase", 424, 55);



     fill(black);
     stroke(white);
     rect(520, 7, 10, 10);     
     rect(520, 22, 10, 10);
     fill(white);
     text("+", 526, 32);
     fill(#F80F07);
     line(523, 12, 527, 12);


    fill(white);
    if (saveDisplay==1){ 
        text("Saved!", 565, 25);     
    }
    if (n>100) {
        saveDisplay = 0;
    }    
        

//FLOWERS!! Set up an algorithm to pick random flower colors:
/*
    if (mouseHeld == 1){

           if (hypoIncrement==0) {    
                colorChooser = (randomGenerator.nextInt(250)%6)+1;
           }
           
          color flowerColor=0;
          
          if (colorChooser == 1){
            flowerColor = #5822A6;
          }
          if (colorChooser == 2){
            flowerColor = #FF753F;
          }
      
          if (colorChooser == 3){
            flowerColor = #DA0315;
          }      

          if (colorChooser == 4){
            flowerColor = #3E664B;
          }
    
          if (colorChooser == 5){
            flowerColor = #1A4E61;
          }

          if (colorChooser == 6){
            flowerColor = #CC016A;
          }     
          
          println(colorChooser);
          
          stroke(#298A0A);
          strokeWeight(3);
          line(mouseX, mouseY, mouseX, mouseY+random(40, 50));

                strokeWeight(1);
      for (int i = 0; i<random(0,5000); i++) {
          stroke(flowerColor);
          line(mouseX-random(0,20)+random(0,20), mouseY+random(0,20)-random(0,20), mouseX-random(0,5)+random(0,5), mouseY+random(0,5)-random(0,5));
          stroke(#E9AC16);
          line(mouseX, mouseY, mouseX-random(0,10)+random(0,10), mouseY+random(0,10)-random(0,10));
          
      }

      hypoIncrement++;
    } 

*/

/*
    if (mouseHeld == 1) {



          
          if (waterXOld-mouseX!=0) {
            hypoIncrement=0;
          }
          
          if (hypoIncrement == 0) {
              hypotenuse = sqrt((sq(abs(waterXOld-mouseX)))+(sq(abs(waterYOld-mouseY)))); 
          }
          
          int xLen = waterXOld - mouseX;
          int yLen = waterYOld - mouseY;
          
          for (int i=1; i<hypotenuse; i++){
             float drawX = mouseX+(xLen/i);
             float drawY = mouseY+(yLen/i);
             
             noStroke();
             fill(#092B5A, 20);
            // ellipse(drawX, drawY, 10, 10);
             fill(#092B5A,20);
             //ellipse(drawX, drawY, 20, 20);
             fill(#092B5A, 40);
             ellipse(drawX, drawY, 30, 30);
             stroke(white);
          }
          
          
          waterXOld = mouseX;
          waterYOld = mouseY;
          hypoIncrement++;
          println(hypotenuse);
    }
*/

/*

          if (mouseHeld == 1) {
              stroke(dirtBrown);
              
                    colorChooser = randomGenerator.nextInt(3)+1;        
                    if (colorChooser == 1){
                      stroke(#2E1E16);
                    }
                    if (colorChooser == 2){
                      stroke(#382219);
                    }
                    if (colorChooser == 3){
                      stroke(#542713);
                    }              
              
                    //Choosing a random sign, + or -
                    sign = random(0,1);
                    if (sign == 0){
                      sign = -1;
                    }
                    
                    int l = 0; 
                    if (l==0){
                      n=100;
                    }
                    strokeWeight(2); 
                    line((mouseX-20)+(30*sign)+sign*random(0, 10), mouseY+random(0,3)-random(0, 3), (mouseX-20)+(30*sign)+sign*random(0, 10), mouseY+n+random(0, 10)); 
                                     
                    l++;
                    
          }
          strokeWeight(1);
*/




//flowers
//rocks
//wind

    frame++;
    n++;
    
    //println("(" + mouseX + ", " + mouseY + ")");
   // println("actionNumber: " + actionNumber);
    //println("numberOfUndos: " + numberOfUndos);
    //println("numberOfRedos: " + numberOfRedos);
    //println("Array item: " + (actionNumber-numberOfUndos));
  }//end of draw()













  
  void mousePressed() {
    mouseHeld = 1;
    n = 100;
    
    if (inMenu != 1) {
      actionNumber++;
      actionNumber = actionNumber - numberOfUndos;
      numberOfUndos = 0;
      numberOfRedos = 0;      
    }
    
    
    
    
    //SEASONS:
    
            //winter:
             if ( (mouseX > 10 && mouseX < 70) && (mouseY > 49 && mouseY < 69) ){
               winterButtonPressed = 1;
               season = winter;
             }
             
             //spring:
             if ( (mouseX > 10 && mouseX < 70) && (mouseY > 79 && mouseY < 99) ){
               springButtonPressed = 1;
               season = spring;
             }
        
             if ( (mouseX > 10 && mouseX < 70) && (mouseY > 109 && mouseY < 129) ){
               summerButtonPressed = 1;
               season = summer;
             }
        
             if ( (mouseX > 10 && mouseX < 70) && (mouseY > 139 && mouseY < 159) ){
               autumnButtonPressed = 1;
               season = autumn;
             }
    
    
    
    
    
    
    
    
    
    
    
    
    
    if (page == 1) {
    
            //Detecting the button presses:
             if ( (mouseX > 10 && mouseX < 50) && (mouseY > 10 && mouseY < 30) ){
               grassButtonPressed = 1;
               state = 1;
             }
             
             if ( (mouseX > 60 && mouseX < 90) && (mouseY > 10 && mouseY < 30) ){
               leavesButtonPressed = 1;
               state = 2;
             }
             
             if ( (mouseX > 110 && mouseX < 140) && (mouseY > 10 && mouseY < 30) ){
               rainButtonPressed = 1;
               state = 4;
             }
             
              if ( (mouseX > 160 && mouseX < 200) && (mouseY > 10 && mouseY < 30) ){
               dirtButtonPressed = 1;
               state = 3;
             }
             
           
              
             if ( (mouseX > 210 && mouseX < 260) && (mouseY > 10 && mouseY < 30) ){
               sunshineButtonPressed = 1;
               state = 6;
             }
             
             if ( (mouseX > 270 && mouseX < 310) && (mouseY > 10 && mouseY < 30) ){
               cloudsButtonPressed = 1;
               state = 7;
             }     
             
             if ( (mouseX > 320 && mouseX < 360) && (mouseY > 10 && mouseY < 30) ){
               skyButtonPressed = 1;
               state = 8;
             }  
             
             if ( (mouseX > 370 && mouseX < 410) && (mouseY > 10 && mouseY < 30) ){
               nightButtonPressed = 1;
               state = 9;
             }     
        
             if ( (mouseX > 420 && mouseX < 460) && (mouseY > 10 && mouseY < 30) ){
               moonButtonPressed = 1;
               state = 10;
             }
        
             if ( (mouseX > 470 && mouseX < 510) && (mouseY > 10 && mouseY < 30) ){
               starsButtonPressed = 1;
               state = 11;
             }
    } //end if (page==1)
    
    
    if (page==2) {
      
                  if ( (mouseX > 10 && mouseX < 50) && (mouseY > 10 && mouseY < 30) ){
                   grassButtonPressed = 1;
                   state = trees;
                 }
                 
              if ( (mouseX > 60 && mouseX < 100) && (mouseY > 10 && mouseY < 30) ){
               flowersButtonPressed = 1;
               state = flowers;
             }
      
      
    }//end if (page==2)
    
    
    
     
     if( (mouseX > 80 && mouseX < 100) && (mouseY > 59 && mouseY < 79) ){
       minusButtonPressed = 1;
       if (frameRateValue > 100) {
         frameRateValue -= 20;
       }
       if (frameRateValue <= 100 && frameRateValue > 40) {
         frameRateValue -= 10; 
       }
       if (frameRateValue <= 40 && frameRateValue > 10) {
         frameRateValue -= 5; 
       }
       if (frameRateValue <= 10 && frameRateValue > 2) {
         frameRateValue -= 1; 
       }
       if (frameRateValue == 2) {
         frameRateValue++;  
       }
     }
     
     if ( (mouseX > 100 && mouseX < 120) && (mouseY > 59 && mouseY < 79) ){
       plusButtonPressed = 1;
       frameRateValue += 20;
     }
     
     if ( (mouseX > (getWidth()-40) && mouseX < getWidth()) && (mouseY > 39 && mouseY < 59) ){
       n = 0;
       saveButtonPressed = 1;
       saveFrame("NaturePainting-##.png");
       saveDisplay = 1;
     }

     if ( (mouseX > (getWidth()-118) && mouseX < getWidth()-79) && (mouseY > 39 && mouseY < 59) && actionNumber > 0 ){
       undoButtonPressed = 1;
       numberOfUndos+=1;
       if (frameHistory[actionNumber-numberOfUndos] != null){
           image(frameHistory[actionNumber-numberOfUndos], 0,0, getWidth(), getHeight());   
       }
     } 
 
     if ( (mouseX > 443 && mouseX < 489) && (mouseY > 39 && mouseY < 59) ){
       clearButtonPressed = 1;
       background(black);
     }    

     if ( (mouseX > 404 && mouseX < 443) && (mouseY > 39 && mouseY < 59) ){
       eraseButtonPressed = 1;
       state = erase;
     } 
     
     if ( (mouseX > 521 && mouseX < 560) && (mouseY > 39 && mouseY < 59) ){
       redoButtonPressed = 1;
       numberOfUndos--;
       if (frameHistory[actionNumber-numberOfUndos] != null){
           image(frameHistory[actionNumber-numberOfUndos], 0,0, getWidth(), getHeight());   
       }       
       
       //image(frameHistory[(actionNumber-numberOfUndos)+numberOfRedos], 0, 0, getWidth(), getHeight());
     }      
   
     if ( (mouseX > 520 && mouseX < 530) && (mouseY > 7 && mouseY < 17) ){
       pageDownButtonPressed = 1;
       if (page != 1) {
         page--;
       }
     }
   
     if ( (mouseX > 520 && mouseX < 530) && (mouseY > 22 && mouseY < 32) ){
       pageUpButtonPressed = 1;
       if (page != 2){
         page++;
       }
     }   
   
   
     
     
  }
  
  void mouseReleased() {
     
     hypoIncrement=0;
    
     if (grassButtonPressed == 1){
       grassButtonPressed = 0;
     }
     
     if (leavesButtonPressed == 1) {
       leavesButtonPressed = 0; 
     }
     
     if (rainButtonPressed == 1) {
       rainButtonPressed = 0; 
     }
     
     if (saveButtonPressed == 1) {
       saveButtonPressed = 0;
     }
     
     if (dirtButtonPressed == 1) {
       dirtButtonPressed = 0;  
     }
     
     if (winterButtonPressed == 1) {
       winterButtonPressed = 0;  
     }
     
     if (springButtonPressed == 1) {
       springButtonPressed = 0;  
     }
     
     if (summerButtonPressed == 1) {
       summerButtonPressed = 0;  
     }
     
     if (autumnButtonPressed == 1) {
       autumnButtonPressed = 0;  
     }
     
     if (sunshineButtonPressed == 1) {
       sunshineButtonPressed = 0;  
     }
 
     if (cloudsButtonPressed == 1) {
       cloudsButtonPressed = 0;
       inMenu = 0;
     }
 
     if (skyButtonPressed == 1) {
       skyButtonPressed = 0;
       inMenu = 0;
     }    

     if (nightButtonPressed == 1) {
       nightButtonPressed = 0;
       inMenu = 0;
     } 

     if (treesButtonPressed == 1) {
       treesButtonPressed = 0;
       inMenu = 0;
     } 

     if (moonButtonPressed == 1) {
       moonButtonPressed = 0;
       inMenu = 0;
     }

     if (starsButtonPressed == 1) {
       starsButtonPressed = 0;
       inMenu = 0;
     }
     
     if (flowersButtonPressed == 1) {
       flowersButtonPressed = 0;
       inMenu = 0;
     }
     
     if (minusButtonPressed == 1) {
       minusButtonPressed = 0; 
       inMenu = 0; 
     }
     
     if (plusButtonPressed == 1) {
       plusButtonPressed = 0;
       inMenu = 0;
     }
     
     if (undoButtonPressed == 1) {
       undoButtonPressed = 0;
       inMenu = 0;
     }     

     if (redoButtonPressed == 1) {
       redoButtonPressed = 0;
       inMenu = 0;
     }
     
     if (clearButtonPressed == 1) {
       clearButtonPressed = 0;
       inMenu = 0;
     }     
     
     if (eraseButtonPressed == 1) {
       eraseButtonPressed = 0;
       inMenu = 0;
     }     
     
     if (inMenu != 1) {
       saveFrame("frameHistory" + actionNumber + ".png");
       PImage frameImage = loadImage("frameHistory" + actionNumber + ".png");
       frameHistory[actionNumber] = frameImage;
     }
     
      mouseHeld = 0; 
  }
  
